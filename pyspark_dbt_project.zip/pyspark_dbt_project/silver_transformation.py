# Databricks notebook source
# MAGIC %md
# MAGIC ## **Customers Table**

# COMMAND ----------

df_cust=spark.read.table("pyspark_dbt.bronze.customer")


# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

import os
import sys

# COMMAND ----------

curr_dir=os.getcwd()
sys.path.append(curr_dir)

# COMMAND ----------

df_cust=df_cust.withColumn("phone_number",regexp_replace("phone_number",('[^0-9]'),''))

# COMMAND ----------

df_cust.display()

# COMMAND ----------

df_cust=df_cust.withColumn('full_name', concat_ws('','first_name','last_name'))

df_cust=df_cust.drop('first_name','last_name')



# COMMAND ----------

from utils.custom_utils import Transformations

# COMMAND ----------

cust_obj=Transformations ()
cust_df_trans=cust_obj.dedup(df_cust,['customer_id'],"last_updated_timestamp")

# COMMAND ----------

if not spark.catalog.tableExists("pyspark_dbt.silver.customer"):

    cust_df_trans.write.format("delta")\
            .mode("append")\
            .saveAsTable("pyspark_dbt.silver.customer")
else:
    cust_obj.upsert(df_cust,['customer_id'],"customer","last_updated_timestamp")    

# COMMAND ----------

# MAGIC %sql
# MAGIC  SELECT COUNT(*)  FROM pyspark_dbt.silver.customer

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **Drivers Table**

# COMMAND ----------

df_drivers=spark.read.table("pyspark_dbt.bronze.drivers")
df_drivers.display()

# COMMAND ----------

from pyspark.sql.functions import regexp_replace, concat_ws
df_drivers=df_drivers.withColumn("phone_number",regexp_replace("phone_number",('[^0-9]'),''))

df_drivers=df_drivers.withColumn('full_name', concat_ws('','first_name','last_name'))

df_drivers=df_drivers.drop('first_name','last_name')



driver_obj=Transformations ()

# COMMAND ----------

df_drivers.display()

# COMMAND ----------

df_drivers_trans=driver_obj.dedup(df_drivers,['driver_id'],"last_updated_timestamp")



# COMMAND ----------

if not spark.catalog.tableExists("pyspark_dbt.silver.drivers"):

    df_drivers_trans.write.format("delta")\
            .mode("append")\
            .saveAsTable("pyspark_dbt.silver.drivers")
else:
    driver_obj.upsert(df_drivers_trans,['driver_id'],"drivers","last_updated_timestamp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Locations**

# COMMAND ----------

df_locations=spark.read.table("pyspark_dbt.bronze.locations")
df_locations.display()

# COMMAND ----------

location_obj=Transformations()
df_locations_trans=location_obj.dedup(df_locations,['location_id'],"last_updated_timestamp")
if not spark.catalog.tableExists("pyspark_dbt.silver.locations"):

    df_locations_trans.write.format("delta")\
            .mode("append")\
            .saveAsTable("pyspark_dbt.silver.locations")
else:
    location_obj.upsert(df_locations_trans,['location_id'],"locations","last_updated_timestamp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Trips**

# COMMAND ----------

df_trips=spark.read.table("pyspark_dbt.bronze.trips")
df_trips.display()

# COMMAND ----------

trips_obj=Transformations()

df_trips_trans=trips_obj.dedup(df_trips,['trip_id'],'last_updated_timestamp')

# COMMAND ----------

if not spark.catalog.tableExists("pyspark_dbt.silver.trips"):

    df_trips_trans.write.format("delta")\
            .mode("append")\
            .saveAsTable("pyspark_dbt.silver.trips")
else:
    trips_obj.upsert(df_trips_trans,['trip_id'],"trips","last_updated_timestamp")


# COMMAND ----------

# MAGIC %md
# MAGIC ## **Payments**

# COMMAND ----------

df_pay=spark.read.table("pyspark_dbt.bronze.payments")
df_pay.display()

# COMMAND ----------

df_pay_trans=df_pay.withColumn("online_payment_status",
                               when(((col("payment_method")=="Card")&(col("payment_status")=="Success")),"online_success")
                               .when(((col("payment_method")=="Card")&(col("payment_status")=="Failed")),"online_failed")
                               .when(((col("payment_method")=="Cash")&(col("payment_status")=="Pending")),"online_pending")
                               .otherwise("offline")
                               
                               )

# COMMAND ----------

df_pay_trans.display()

# COMMAND ----------

pay_obj=Transformations()
df_pay_trans=pay_obj.dedup(df_pay,['payment_id'],'last_updated_timestamp')


if not spark.catalog.tableExists("pyspark_dbt.silver.payments"):

    df_pay_trans.write.format("delta")\
                .mode("append")\
                .saveAsTable("pyspark_dbt.silver.payments")
else:
    pay_obj.upsert(df_pay_trans,['payment_id'],"payments","last_updated_timestamp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Vehicles**

# COMMAND ----------

df_veh=spark.read.table("pyspark_dbt.bronze.vehicles")
df_veh.display()

# COMMAND ----------

df_veh=df_veh.withColumn("make",upper(col("make")))

# COMMAND ----------

veh_obj=Transformations()
df_veh_trans=veh_obj.dedup(df_veh,['vehicle_id'],'last_updated_timestamp')


if not spark.catalog.tableExists("pyspark_dbt.silver.vehicles"):

    df_veh_trans.write.format("delta").saveAsTable("pyspark_dbt.silver.vehicles")
else:
    veh_obj.upsert(df_veh_trans,['vehicle_id'],"vehicles","last_updated_timestamp")

   

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS pyspark_dbt.silver.payments;

# COMMAND ----------

