# Databricks notebook source
# MAGIC %md
# MAGIC ## **PYSPARK STREAMING**

# COMMAND ----------

entities=['customer','trips','drivers','payments','locations','vehicles']

# COMMAND ----------

for entity in entities:
        df=spark.read.format("csv")\
                .option("header",True)\
                .option("inferSchema",True)\
                .load(f'/Volumes/pyspark_dbt/source/source_data/{entity}/')
        batch_schema=df.schema

        df=spark.readStream.format("csv")\
                .option("header","true")\
                .option("inferSchema","true")\
                .schema(batch_schema)\
                .load(f'/Volumes/pyspark_dbt/source/source_data/{entity}/')
        df.writeStream.format("delta")\
                      .outputMode("append")\
                      .option("checkpointLocation",f"/Volumes/pyspark_dbt/bronze/checkpoints/{entity}")\
                      .trigger(once=True)\
                      .toTable(f"pyspark_dbt.bronze.{entity}")          
      
        
        

# COMMAND ----------

