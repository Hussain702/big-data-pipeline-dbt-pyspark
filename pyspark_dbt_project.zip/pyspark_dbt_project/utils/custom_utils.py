# from pyspark.sql.functions import *
from pyspark.sql.functions import concat, row_number, col, current_timestamp
from pyspark.sql.types import *
from pyspark.sql import *
from pyspark.sql.window import Window
from typing import List
from pyspark.sql import DataFrame
from delta.tables import DeltaTable


class Transformations:

    def dedup(self,df:DataFrame,col_list:List,cdc:str):
        df = df.withColumn("dedup_key",concat(*col_list))
        df = df.withColumn("dedup_counts",row_number().over(Window.partitionBy("dedup_key").orderBy(col(cdc).desc())))
        df = df.filter(col("dedup_counts")==1)
        df = df.drop("dedup_key","dedup_counts")
        return df
    
    def process_timestamp(self,df):
        df=df.withColumn("process_timestamp",current_timestamp())
        return df
    
    def upsert(self,df,key_cols,cdc):
        merge_conditon= " AND ".join([f"src.{i}=trg.{i}" for i in key_cols])
        dlt_obj=DeltaTable.forName(spark,f"pyspark_dbt.silver.{table}")
        dlt_obj.alias("trg").merge(df.alias("src"),merge_conditon)\
               .whenMatchedUpdateAll(condition=f"src.{cdc}>=trg.{cdc}")\
               .whenNotMatchedInsertAll()\
               .execute()