{{ 
    config(
        materialized='view'
    ) 
}}

WITH total_fare AS (

    SELECT 
        t.customer_id,
        t.fare_amount,
        c.city
    FROM
        {{ ref('trips') }} AS t

    JOIN 
        {{ ref('dim_customers') }} AS c
    ON      
        t.customer_id = c.customer_id
)

SELECT 
    city, 
    SUM(fare_amount) AS total_fare_city  
FROM 
    total_fare
GROUP BY 
    city
ORDER BY 
    total_fare_city DESC