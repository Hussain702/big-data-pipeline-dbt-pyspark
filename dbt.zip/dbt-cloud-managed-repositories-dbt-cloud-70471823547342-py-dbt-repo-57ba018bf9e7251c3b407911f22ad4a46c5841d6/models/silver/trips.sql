{{
    config(
        materialized='incremental',
        unique_key='trip_id'
    )
}}

{% set col=['trip_id','customer_id','vehicle_id','driver_id','trip_start_time','trip_end_time','distance_km','fare_amount','trip_status','payment_method','last_updated_timestamp'] %}

SELECT
  {% for c in col %}
       {{c}}
       {% if not loop.last %},{% endif %}
   {% endfor %}   
FROM 
   {{source('source_bronze','trips')}}   
{% if is_incremental() %}
WHERE  last_updated_timestamp>(SELECT coalesce(max(last_updated_timestamp),'1900-01-01') FROM {{this}})

{% endif %}
      